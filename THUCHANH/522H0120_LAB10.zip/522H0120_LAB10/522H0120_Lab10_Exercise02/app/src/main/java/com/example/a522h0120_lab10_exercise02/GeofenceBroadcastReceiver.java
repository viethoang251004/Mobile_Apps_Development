package com.example.a522h0120_lab10_exercise02;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.google.android.gms.location.GeofencingEvent;

public class GeofenceBroadcastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        GeofencingEvent event = GeofencingEvent.fromIntent(intent);
        if (event.hasError()) {
            Log.e("Geofence", "Error: " + event.getErrorCode());
            return;
        }

        if (event.getGeofenceTransition() == Geofence.GEOFENCE_TRANSITION_ENTER) {
            String geofenceId = event.getTriggeringGeofences().get(0).getRequestId();
            if (geofenceId.equals("TDTUniversity200m")) {
                Log.d("Geofence", "Bạn đang ở gần Trường Đại học Tôn Đức Thắng.");
            } else if (geofenceId.equals("TDTUniversity30m")) {
                Log.d("Geofence", "Chào mừng bạn đến với trường Đại học Tôn Đức Thắng.");
            }
        }
    }
}
