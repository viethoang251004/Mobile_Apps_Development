package com.example.a522h0120_lab10_exercise1;

public class ContactDetailsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_details);

        Contact contact = (Contact) getIntent().getSerializableExtra("CONTACT");

        ImageView imgAvatar = findViewById(R.id.imgAvatarLarge);
        TextView txtName = findViewById(R.id.txtNameDetails);
        TextView txtPhone = findViewById(R.id.txtPhone);
        TextView txtEmail = findViewById(R.id.txtEmail);
        TextView txtAddress = findViewById(R.id.txtAddress);

        if (contact != null) {
            imgAvatar.setImageResource(contact.getAvatarResId());
            txtName.setText(contact.getName());
            txtPhone.setText("Phone: " + contact.getPhone());
            txtEmail.setText("Email: " + contact.getEmail());
            txtAddress.setText("Address: " + contact.getAddress());
        }
    }
}
