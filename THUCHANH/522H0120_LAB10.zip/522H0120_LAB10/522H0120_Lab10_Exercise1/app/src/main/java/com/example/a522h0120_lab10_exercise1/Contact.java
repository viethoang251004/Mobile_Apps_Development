package com.example.a522h0120_lab10_exercise1;

public class Contact {
    private String name;
    private int avatarResId; // Drawable resource ID
    private String phone;
    private String email;
    private String address;

    public Contact(String name, int avatarResId, String phone, String email, String address) {
        this.name = name;
        this.avatarResId = avatarResId;
        this.phone = phone;
        this.email = email;
        this.address = address;
    }

    public String getName() { return name; }
    public int getAvatarResId() { return avatarResId; }
    public String getPhone() { return phone; }
    public String getEmail() { return email; }
    public String getAddress() { return address; }
}
