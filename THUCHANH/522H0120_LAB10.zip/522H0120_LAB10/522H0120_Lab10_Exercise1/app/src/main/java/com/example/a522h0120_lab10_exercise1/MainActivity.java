package com.example.a522h0120_lab10_exercise1;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<Contact> contactList = Arrays.asList(
                new Contact("John Doe", R.drawable.ic_avatar_placeholder, "123456789", "john@example.com", "123 Street Name"),
                new Contact("Jane Smith", R.drawable.ic_avatar_placeholder, "987654321", "jane@example.com", "456 Avenue Name")
        );

        ContactAdapter adapter = new ContactAdapter(contactList, this);
        recyclerView.setAdapter(adapter);
    }
}
