package com.example.a522h0120_lab10_exercise03;

import android.hardware.biometrics.BiometricPrompt;
import android.os.Bundle;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        BiometricPrompt biometricPrompt = new BiometricPrompt.Builder(this)
                .setTitle("Fingerprint Authentication")
                .setSubtitle("Authenticate to access settings")
                .setNegativeButton("Cancel", this.getMainExecutor(), (dialog, which) -> finish())
                .build();

        biometricPrompt.authenticate(new BiometricPrompt.CryptoObject(null), new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                // Hiển thị SettingsFragment
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(android.R.id.content, new SettingsFragment())
                        .commit();
            }

            @Override
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                Toast.makeText(SettingsActivity.this, "Authentication failed", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }
}
